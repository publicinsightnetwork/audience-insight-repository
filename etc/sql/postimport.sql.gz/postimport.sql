COMMIT;
SET autocommit=1;
SET unique_checks=1;
SET foreign_key_checks=1;
